# Firestore data model (initial)

Collection: `users/{uid}`

Example document:
```json
{
  "name": "Employee Name",
  "email": "person@example.com",
  "phone": "01XXXXXXXXX",
  "position": "Manager",
  "role": "manager",
  "active": true,
  "createdAt": "server timestamp"
}
```

Allowed role strings:
- owner
- manager
- head_employee
- assistant_manager
- employee
- driver

**Critical:** do not let a user set or change their own `role` or `active` fields. Provision the three owner UIDs manually using a trusted admin environment before enabling employee registration. All three owners receive the same `owner` role. The app reads role from Firestore; this is not a substitute for strict Firestore Security Rules.
