package com.jakirltd.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
