# Cloud APK build – Zakir Limited

This package adds a GitHub Actions workflow at `.github/workflows/android-apk.yml`.
It is designed to build the release APK on GitHub's hosted Ubuntu runner and upload
it as an artifact named `zakir-limited-release-apk`.

## How to run it
1. Create a private GitHub repository and upload/extract the full project contents.
2. Push the project to the `main` branch, or open the repository's Actions tab.
3. Select **Build Zakir Limited APK** and press **Run workflow**.
4. Wait for the workflow to finish. If successful, open the run and download the
   `zakir-limited-release-apk` artifact. The APK is inside that downloaded artifact.

## Important limits
- This is a build workflow, not an APK. The APK is created only after the workflow
  successfully runs in GitHub Actions.
- The workflow runs `flutter create . --platforms=android` to generate missing
  Flutter wrapper/platform files, then runs `flutter pub get` and `flutter build apk --release`.
- If the workflow reports an Android Gradle/plugin or project-generation error, its
  build log is needed to fix the exact issue.
- Firebase Authentication Email/Password must be enabled and Firestore must exist.
- The current app remains a role-login/dashboard prototype; the full Hanif Door factory
  features are not implemented.
