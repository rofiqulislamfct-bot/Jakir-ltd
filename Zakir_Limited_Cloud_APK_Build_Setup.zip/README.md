# Zakir Limited – Role Login Stage

This stage adds Firebase email/password sign-in, auth-state routing, Firestore profile lookup, active-account check, and six role-specific dashboard layouts.

## Firebase setup required
1. Install Flutter SDK and Android Studio.
2. The supplied Firebase Android configuration is included at `android/app/google-services.json`.
3. In the project folder run `flutter create .` to generate Android platform files if missing. If the generated Android folder replaces the supplied config, copy `google-services.json` back to `android/app/`.
4. Run `flutterfire configure` and select the existing Firebase project. This generates `lib/firebase_options.dart`.
5. In `lib/main.dart`, import `firebase_options.dart` and replace the commented initialization with:
   `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
6. Firebase Console → Authentication → Sign-in method → enable Email/Password.
7. Create Firestore database.
8. Create `users/{uid}` profile documents as described in `firestore/README.md`.
9. Run `flutter pub get`, then `flutter run`.

## Security and current limitations
- Role-based routing is implemented in Flutter, but production authorization is NOT complete until Firestore Security Rules and trusted owner provisioning are configured.
- Do not allow public self-registration to choose the `owner` role.
- All three named owners must be securely mapped to their actual Firebase UIDs by a trusted setup process. The three owners share the same `owner` role.
- This source package is not an APK and has not been built or device-tested in this environment.
- Attendance GPS/camera, payroll, orders, driver tracking, push notifications, voice/video calls, reports, backup and audit logs are future modules, not implemented here.


## Firebase initialization included in this package
- `lib/main.dart` now initializes Firebase using the Android values from the supplied `google-services.json`.
- `firestore.rules` is a deliberately restrictive starter ruleset: users can read only their own `users/{uid}` profile; client-side writes are denied.
- Publish the rules in Firebase Console → Firestore Database → Rules before testing.
- Create each employee profile through a trusted admin process. Never let a user choose their own `owner` role.
- This ZIP still does not include a compiled APK or a complete Android Gradle project. Android build files must be generated with Flutter tooling, then the app must be built and tested.


See `ANDROID_BUILD_SETUP.md` for the Android Gradle scaffold and build steps.
