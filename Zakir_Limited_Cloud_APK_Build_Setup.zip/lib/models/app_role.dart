enum AppRole {
  owner,
  manager,
  headEmployee,
  assistantManager,
  employee,
  driver,
}

AppRole? roleFromString(String? value) {
  switch (value) {
    case 'owner': return AppRole.owner;
    case 'manager': return AppRole.manager;
    case 'head_employee': return AppRole.headEmployee;
    case 'assistant_manager': return AppRole.assistantManager;
    case 'employee': return AppRole.employee;
    case 'driver': return AppRole.driver;
    default: return null;
  }
}

extension AppRoleText on AppRole {
  String get label {
    switch (this) {
      case AppRole.owner: return 'মালিক / Owner';
      case AppRole.manager: return 'ম্যানেজার / Manager';
      case AppRole.headEmployee: return 'হেড কর্মচারী / Head Employee';
      case AppRole.assistantManager: return 'সহকারী ম্যানেজার / Assistant Manager';
      case AppRole.employee: return 'কর্মচারী / Employee';
      case AppRole.driver: return 'ডেলিভারি ড্রাইভার / Driver';
    }
  }
}
