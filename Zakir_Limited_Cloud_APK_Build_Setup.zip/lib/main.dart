import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'screens/auth_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyD0dSV6BayRxmYKRfZa97bPgCSNKDCZp74',
      appId: '1:235034327378:android:bf664026c5ff705a36e28b',
      messagingSenderId: '235034327378',
      projectId: 'jakir-ltd',
      storageBucket: 'jakir-ltd.firebasestorage.app',
    ),
  );
  runApp(const ZakirLimitedApp());
}

class ZakirLimitedApp extends StatelessWidget {
  const ZakirLimitedApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Zakir Limited',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF173B57)),
        ),
        home: const AuthGate(),
      );
}
