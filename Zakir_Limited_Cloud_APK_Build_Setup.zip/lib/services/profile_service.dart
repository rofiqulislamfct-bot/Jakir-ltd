import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/app_role.dart';

class AppProfile {
  const AppProfile({required this.uid, required this.name, required this.role,
    required this.active, this.position = ''});
  final String uid;
  final String name;
  final AppRole role;
  final bool active;
  final String position;
}

class ProfileService {
  final _db = FirebaseFirestore.instance;

  Future<AppProfile?> loadCurrentProfile(User user) async {
    final doc = await _db.collection('users').doc(user.uid).get();
    if (!doc.exists) return null;
    final data = doc.data()!;
    final role = roleFromString(data['role'] as String?);
    if (role == null) return null;
    return AppProfile(
      uid: user.uid,
      name: (data['name'] as String?) ?? user.email ?? 'ব্যবহারকারী',
      role: role,
      active: data['active'] == true,
      position: (data['position'] as String?) ?? '',
    );
  }
}
