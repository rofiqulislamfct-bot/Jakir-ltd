import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/profile_service.dart';
import 'dashboard_screen.dart';
import 'login_screen.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final user = snapshot.data;
        if (user == null) return const LoginScreen();
        return FutureBuilder(
          future: ProfileService().loadCurrentProfile(user),
          builder: (context, profileSnapshot) {
            if (profileSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            if (profileSnapshot.hasError) {
              return const _AccessMessage(
                message: 'প্রোফাইল লোড করা যায়নি। ইন্টারনেট ও Firestore rules পরীক্ষা করুন।');
            }
            final profile = profileSnapshot.data;
            if (profile == null) {
              return const _AccessMessage(
                message: 'আপনার অ্যাকাউন্টের Role সেট করা হয়নি। মালিকের অনুমোদন প্রয়োজন।');
            }
            if (!profile.active) {
              return const _AccessMessage(
                message: 'আপনার অ্যাকাউন্ট বর্তমানে নিষ্ক্রিয়। মালিকের সঙ্গে যোগাযোগ করুন।');
            }
            return DashboardScreen(profile: profile);
          },
        );
      },
    );
  }
}

class _AccessMessage extends StatelessWidget {
  const _AccessMessage({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.lock_outline, size: 44),
        const SizedBox(height: 16),
        Text(message, textAlign: TextAlign.center),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: () => FirebaseAuth.instance.signOut(),
          child: const Text('লগআউট'),
        ),
      ]),
    )),
  );
}
