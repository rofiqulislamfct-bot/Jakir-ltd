import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/app_role.dart';
import '../services/profile_service.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.profile});
  final AppProfile profile;

  List<(String, IconData)> get tiles => switch (profile.role) {
    AppRole.owner => [
      ('কর্মচারী ব্যবস্থাপনা', Icons.people),
      ('উৎপাদন পর্যবেক্ষণ', Icons.precision_manufacturing),
      ('অর্ডার ও ডেলিভারি', Icons.local_shipping),
      ('বেতন ও আর্থিক রিপোর্ট', Icons.account_balance),
      ('অনুমোদন ও জরিমানা', Icons.verified_user),
      ('ফ্যাক্টরি রিপোর্ট', Icons.factory),
    ],
    AppRole.manager => [
      ('হাজিরা পর্যবেক্ষণ', Icons.fact_check),
      ('উৎপাদন ব্যবস্থাপনা', Icons.construction),
      ('অর্ডার ও মেমো', Icons.assignment),
      ('দৈনিক ক্লোজিং রিপোর্ট', Icons.lock),
    ],
    AppRole.headEmployee => [
      ('কাজ বণ্টন', Icons.groups),
      ('উৎপাদন রিপোর্ট', Icons.summarize),
      ('দৈনিক টার্গেট', Icons.flag),
    ],
    AppRole.assistantManager => [
      ('সহকারী দায়িত্ব', Icons.assignment_ind),
      ('হাজিরা সহায়তা', Icons.fact_check),
      ('নোটিফিকেশন', Icons.notifications),
    ],
    AppRole.employee => [
      ('চেক-ইন / চেক-আউট', Icons.login),
      ('আজকের কাজ', Icons.work),
      ('উৎপাদন রিপোর্ট', Icons.edit_note),
      ('বেতন ও ভাতা', Icons.payments),
    ],
    AppRole.driver => [
      ('আমার ডেলিভারি', Icons.local_shipping),
      ('লোডিং নিশ্চিতকরণ', Icons.inventory),
      ('ডেলিভারি আপডেট', Icons.route),
    ],
  };

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Zakir Limited'), actions: [
      IconButton(tooltip: 'লগআউট', onPressed: () => FirebaseAuth.instance.signOut(),
        icon: const Icon(Icons.logout)),
    ]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: const Color(0xFF173B57), borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('HANIF DOOR', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text('স্বাগতম, ${profile.name}', style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(profile.role.label, style: const TextStyle(color: Colors.white70)),
        ])),
      const SizedBox(height: 18),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35,
        children: tiles.map((tile) => Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(tile.$2, size: 30, color: const Color(0xFF173B57)),
            const SizedBox(height: 10),
            Text(tile.$1, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
          ]),
        ))).toList()),
      const SizedBox(height: 12),
      const Text('মডিউলগুলো পরবর্তী ডেভেলপমেন্ট ধাপে ডেটাবেজ ও অনুমতি দিয়ে সক্রিয় করা হবে।',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
    ]),
  );
}
