import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  String? _error;

  @override
  void dispose() { _email.dispose(); _password.dispose(); super.dispose(); }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() { _busy = true; _error = null; });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(), password: _password.text);
    } on FirebaseAuthException catch (e) {
      setState(() => _error = switch (e.code) {
        'invalid-credential' || 'user-not-found' || 'wrong-password' =>
          'ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।',
        'too-many-requests' => 'অনেকবার চেষ্টা হয়েছে। পরে চেষ্টা করুন।',
        'network-request-failed' => 'ইন্টারনেট সংযোগ পরীক্ষা করুন।',
        _ => 'লগইন ব্যর্থ: ${e.code}',
      });
    } catch (_) {
      setState(() => _error = 'লগইন ব্যর্থ। Firebase কনফিগারেশন পরীক্ষা করুন।');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(22),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440),
        child: Form(key: _form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.factory_outlined, size: 54, color: Color(0xFF173B57)),
          const SizedBox(height: 12),
          const Text('ZAKIR LIMITED', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const Text('HANIF DOOR • FACTORY MANAGEMENT', textAlign: TextAlign.center),
          const SizedBox(height: 34),
          const Text('স্বাগতম', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextFormField(controller: _email, keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Gmail / Email', prefixIcon: Icon(Icons.email), border: OutlineInputBorder()),
            validator: (v) => (v == null || !v.contains('@')) ? 'সঠিক ইমেইল লিখুন' : null),
          const SizedBox(height: 14),
          TextFormField(controller: _password, obscureText: _hide,
            decoration: InputDecoration(labelText: 'পাসওয়ার্ড', prefixIcon: const Icon(Icons.lock),
              suffixIcon: IconButton(onPressed: () => setState(() => _hide = !_hide),
                icon: Icon(_hide ? Icons.visibility : Icons.visibility_off)),
              border: const OutlineInputBorder()),
            validator: (v) => (v == null || v.length < 6) ? 'কমপক্ষে ৬ অক্ষর দিন' : null),
          if (_error != null) ...[const SizedBox(height: 12), Text(_error!, style: const TextStyle(color: Colors.red))],
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _submit,
            child: _busy ? const CircularProgressIndicator() : const Text('লগইন করুন')),
          TextButton(onPressed: () async {
            final email = _email.text.trim();
            if (!email.contains('@')) { setState(() => _error = 'আগে ইমেইল লিখুন'); return; }
            try {
              await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
              setState(() => _error = 'পাসওয়ার্ড রিসেট ইমেইল পাঠানো হয়েছে।');
            } catch (_) { setState(() => _error = 'রিসেট ইমেইল পাঠানো যায়নি।'); }
          }, child: const Text('পাসওয়ার্ড ভুলে গেছেন?')),
        ])),
      ),
    ))),
  );
}
